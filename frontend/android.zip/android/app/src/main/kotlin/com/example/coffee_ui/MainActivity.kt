<<<<<<< HEAD
package com.example.coffee_ui
=======
package com.mochamingle.app
>>>>>>> 94a3958 (todaycommit)

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
